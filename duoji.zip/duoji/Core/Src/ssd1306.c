#include "ssd1306.h"
#include "ssd1306_font.h"
#include <string.h>

extern I2C_HandleTypeDef hi2c1;

#define SSD1306_ADDR  0x78

static uint8_t oled_inited = 0;

/* ================================================================
 *  I2C bus unstick — workaround STM32F1 BUSY flag silicon bug
 * ================================================================ */
static void I2C_Unstick(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    uint8_t i;

    /* Disable I2C1 */
    hi2c1.Instance->CR1 &= ~I2C_CR1_PE;

    /* Configure PB6(SCL) and PB7(SDA) as open-drain output */
    GPIO_InitStruct.Pin   = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* Set SDA high, then clock SCL 9 times to release stuck slave */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
    for (i = 0; i < 9; i++) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
        HAL_Delay(1);
    }
    /* Generate STOP: SCL high, then SDA rising */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);

    /* Reconfigure back to I2C */
    GPIO_InitStruct.Pin   = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* Re-enable I2C1 */
    hi2c1.Instance->CR1 |= I2C_CR1_PE;
}

/* ================================================================
 *  Low-level I2C  (using Master_Transmit, more reliable on STM32F1)
 * ================================================================ */
static HAL_StatusTypeDef WriteCmd(uint8_t cmd)
{
    uint8_t buf[2] = {0x00, cmd};
    return HAL_I2C_Master_Transmit(&hi2c1, SSD1306_ADDR, buf, 2, 100);
}

static HAL_StatusTypeDef WriteData(uint8_t data)
{
    uint8_t buf[2] = {0x40, data};
    return HAL_I2C_Master_Transmit(&hi2c1, SSD1306_ADDR, buf, 2, 100);
}

/* ================================================================
 *  Initialization
 * ================================================================ */
void OLED_Init(void)
{
    if (oled_inited) return;

    HAL_Delay(200);

    WriteCmd(0xAE); // Display off

    WriteCmd(0xD5); // Clock div
    WriteCmd(0x80);

    WriteCmd(0xA8); // Multiplex
    WriteCmd(0x3F); // 64 rows

    WriteCmd(0xD3); // Display offset
    WriteCmd(0x00);

    WriteCmd(0x40); // Start line = 0

    WriteCmd(0xA1); // Segment remap (normal)

    WriteCmd(0xC8); // COM scan direction (normal)

    WriteCmd(0xDA); // COM pins
    WriteCmd(0x12);

    WriteCmd(0x81); // Contrast
    WriteCmd(0xCF);

    WriteCmd(0xD9); // Pre-charge
    WriteCmd(0xF1);

    WriteCmd(0xDB); // VCOMH
    WriteCmd(0x30);

    WriteCmd(0xA4); // Normal display (not all-on)

    WriteCmd(0xA6); // Normal (not inverted)

    WriteCmd(0x8D); // Charge pump
    WriteCmd(0x14); // Enable

    WriteCmd(0xAF); // Display on

    OLED_Clear();
    oled_inited = 1;
}

/* ================================================================
 *  Auto-init guard
 * ================================================================ */
static void ensure_inited(void)
{
    if (!oled_inited) OLED_Init();
}

/* ================================================================
 *  Clear / Fill
 * ================================================================ */
void OLED_Clear(void)
{
    uint8_t i, n;
    for (i = 0; i < 8; i++) {
        WriteCmd(0xB0 | i);
        WriteCmd(0x00);
        WriteCmd(0x10);
        for (n = 0; n < 128; n++)
            WriteData(0x00);
    }
}

void OLED_Fill(void)
{
    uint8_t i, n;
    for (i = 0; i < 8; i++) {
        WriteCmd(0xB0 | i);
        WriteCmd(0x00);
        WriteCmd(0x10);
        for (n = 0; n < 128; n++)
            WriteData(0xFF);
    }
}

/* ================================================================
 *  Display control
 * ================================================================ */
void OLED_Display_On(void)
{
    WriteCmd(0x8D);
    WriteCmd(0x14);
    WriteCmd(0xAF);
}

void OLED_Display_Off(void)
{
    WriteCmd(0x8D);
    WriteCmd(0x10);
    WriteCmd(0xAE);
}

/* ================================================================
 *  Cursor (page addressing)
 * ================================================================ */
void OLED_SetCursor(uint8_t x, uint8_t y)
{
    WriteCmd(0xB0 | y);
    WriteCmd(((x & 0xF0) >> 4) | 0x10);
    WriteCmd(x & 0x0F);
}

/* ================================================================
 *  Character display
 * ================================================================ */
void OLED_ShowChar(uint8_t x, uint8_t y, char chr, uint8_t size)
{
    uint8_t i, c;

    ensure_inited();

    c = chr - ' ';
    if (x > 128 - 1) { x = 0; y += 2; }

    if (size == 16) {
        OLED_SetCursor(x, y);
        for (i = 0; i < 8; i++)
            WriteData(F8X16[c * 16 + i]);
        OLED_SetCursor(x, y + 1);
        for (i = 0; i < 8; i++)
            WriteData(F8X16[c * 16 + i + 8]);
    } else {
        OLED_SetCursor(x, y);
        for (i = 0; i < 6; i++)
            WriteData(F6x8[c][i]);
    }
}

void OLED_ShowString(uint8_t x, uint8_t y, const char *str, uint8_t size)
{
    ensure_inited();

    while (*str) {
        OLED_ShowChar(x, y, *str, size);
        x += 8;
        if (x > 120) { x = 0; y += 2; }
        str++;
    }
}

/* ================================================================
 *  Number display
 * ================================================================ */
static uint32_t oled_pow(uint8_t m, uint8_t n)
{
    uint32_t result = 1;
    while (n--) result *= m;
    return result;
}

void OLED_ShowNum(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size)
{
    uint8_t t, temp, enshow = 0;
    ensure_inited();
    for (t = 0; t < len; t++) {
        temp = (num / oled_pow(10, len - t - 1)) % 10;
        if (enshow == 0 && t < (len - 1)) {
            if (temp == 0) {
                OLED_ShowChar(x + (size / 2) * t, y, ' ', size);
                continue;
            } else enshow = 1;
        }
        OLED_ShowChar(x + (size / 2) * t, y, temp + '0', size);
    }
}

void OLED_ShowSignedNum(uint8_t x, uint8_t y, int32_t num, uint8_t len, uint8_t size)
{
    uint8_t t;
    uint32_t num1;
    ensure_inited();
    if (num >= 0) {
        OLED_ShowChar(x, y, '+', size);
        num1 = num;
    } else {
        OLED_ShowChar(x, y, '-', size);
        num1 = -num;
    }
    for (t = 0; t < len; t++) {
        OLED_ShowChar(x + (size / 2) * (t + 1), y, (num1 / oled_pow(10, len - t - 1)) % 10 + '0', size);
    }
}

void OLED_ShowHexNum(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size)
{
    uint8_t t, n;
    ensure_inited();
    for (t = 0; t < len; t++) {
        n = (num / oled_pow(16, len - t - 1)) % 16;
        OLED_ShowChar(x + (size / 2) * t, y, n < 10 ? n + '0' : n - 10 + 'A', size);
    }
}


/* ================================================================
 *  Drawing (direct-write, single-pixel-at-a-time)
 * ================================================================ */

/* Single-page shadow buffer for DrawPixel (SSD1306 can't read back over I2C) */
static uint8_t page_buf[128];

void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color)
{
    uint8_t page;
    if (x >= 128 || y >= 64) return;
    page = y / 8;
    if (color)
        page_buf[x] |=  (1 << (y & 7));
    else
        page_buf[x] &= ~(1 << (y & 7));
    OLED_SetCursor(x, page);
    WriteData(page_buf[x]);
}

void OLED_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint8_t color)
{
    int16_t dx = (int16_t)(x1 > x0 ? x1 - x0 : x0 - x1);
    int16_t dy = (int16_t)(y1 > y0 ? y1 - y0 : y0 - y1);
    int16_t sx = x0 < x1 ? 1 : -1;
    int16_t sy = y0 < y1 ? 1 : -1;
    int16_t err = dx - dy, e2;
    while (1) {
        OLED_DrawPixel(x0, y0, color);
        if (x0 == x1 && y0 == y1) break;
        e2 = err * 2;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 <  dx) { err += dx; y0 += sy; }
    }
}

void OLED_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color)
{
    OLED_DrawLine(x, y, x + w - 1, y, color);
    OLED_DrawLine(x, y + h - 1, x + w - 1, y + h - 1, color);
    OLED_DrawLine(x, y, x, y + h - 1, color);
    OLED_DrawLine(x + w - 1, y, x + w - 1, y + h - 1, color);
}

void OLED_DrawFilledRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color)
{
    uint8_t i;
    for (i = 0; i < h; i++)
        OLED_DrawLine(x, y + i, x + w - 1, y + i, color);
}

void OLED_DrawCircle(int8_t x0, int8_t y0, uint8_t r, uint8_t color)
{
    int16_t f = 1 - r, dx = 1, dy = -2 * r, x = 0, y = r;
    OLED_DrawPixel(x0, y0 + r, color);
    OLED_DrawPixel(x0, y0 - r, color);
    OLED_DrawPixel(x0 + r, y0, color);
    OLED_DrawPixel(x0 - r, y0, color);
    while (x < y) {
        if (f >= 0) { y--; dy += 2; f += dy; }
        x++; dx += 2; f += dx;
        OLED_DrawPixel(x0 + x, y0 + y, color);
        OLED_DrawPixel(x0 - x, y0 + y, color);
        OLED_DrawPixel(x0 + x, y0 - y, color);
        OLED_DrawPixel(x0 - x, y0 - y, color);
        OLED_DrawPixel(x0 + y, y0 + x, color);
        OLED_DrawPixel(x0 - y, y0 + x, color);
        OLED_DrawPixel(x0 + y, y0 - x, color);
        OLED_DrawPixel(x0 - y, y0 - x, color);
    }
}

void OLED_DrawFilledCircle(int8_t x0, int8_t y0, uint8_t r, uint8_t color)
{
    int16_t f = 1 - r, dx = 1, dy = -2 * r, x = 0, y = r;
    OLED_DrawLine(x0, y0 - r, x0, y0 + r, color);
    while (x < y) {
        if (f >= 0) { y--; dy += 2; f += dy; }
        x++; dx += 2; f += dx;
        OLED_DrawLine(x0 + x, y0 - y, x0 + x, y0 + y, color);
        OLED_DrawLine(x0 - x, y0 - y, x0 - x, y0 + y, color);
        OLED_DrawLine(x0 + y, y0 - x, x0 + y, y0 + x, color);
        OLED_DrawLine(x0 - y, y0 - x, x0 - y, y0 + x, color);
    }
}
