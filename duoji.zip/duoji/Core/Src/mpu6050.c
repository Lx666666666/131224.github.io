#include "mpu6050.h"
#include "i2c.h"

extern I2C_HandleTypeDef hi2c2;

#define MPU_I2C_TIMEOUT  1000

/* ================================================================
 *  Hardware I2C2 write
 * ================================================================ */
uint8_t MPU_Write_Len(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf)
{
    if (HAL_I2C_Mem_Write(&hi2c2, addr << 1, reg,
                          I2C_MEMADD_SIZE_8BIT, buf, len,
                          MPU_I2C_TIMEOUT) != HAL_OK)
        return 1;
    return 0;
}

/* ================================================================
 *  Hardware I2C2 read
 * ================================================================ */
uint8_t MPU_Read_Len(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf)
{
    if (HAL_I2C_Mem_Read(&hi2c2, addr << 1, reg,
                         I2C_MEMADD_SIZE_8BIT, buf, len,
                         MPU_I2C_TIMEOUT) != HAL_OK)
        return 1;
    return 0;
}

/* ================================================================
 *  Single byte write
 * ================================================================ */
uint8_t MPU_Write_Byte(uint8_t reg, uint8_t data)
{
    return MPU_Write_Len(MPU_ADDR, reg, 1, &data);
}

/* ================================================================
 *  Single byte read
 * ================================================================ */
uint8_t MPU_Read_Byte(uint8_t reg)
{
    uint8_t res;
    MPU_Read_Len(MPU_ADDR, reg, 1, &res);
    return res;
}

/* ================================================================
 *  MPU6050 Init
 * ================================================================ */
uint8_t MPU_Init(void)
{
    uint8_t res;

    MPU_Write_Byte(MPU_PWR_MGMT1_REG, 0X80);   // Reset MPU6050
    delay_ms(100);
    MPU_Write_Byte(MPU_PWR_MGMT1_REG, 0X00);   // Wake up
    MPU_Set_Gyro_Fsr(3);                       // Gyro: +/-2000dps
    MPU_Set_Accel_Fsr(0);                      // Accel: +/-2g
    MPU_Set_Rate(100);                         // Sample rate 100Hz
    MPU_Write_Byte(MPU_INT_EN_REG, 0X00);      // Disable all interrupts
    MPU_Write_Byte(MPU_USER_CTRL_REG, 0X00);   // I2C master mode off
    MPU_Write_Byte(MPU_FIFO_EN_REG, 0X00);     // FIFO off
    MPU_Write_Byte(MPU_INTBP_CFG_REG, 0X80);   // INT pin active low
    res = MPU_Read_Byte(MPU_DEVICE_ID_REG);
    if (res == MPU_ADDR) {
        MPU_Write_Byte(MPU_PWR_MGMT1_REG, 0X01);   // CLKSEL: PLL X ref
        MPU_Write_Byte(MPU_PWR_MGMT2_REG, 0X00);   // Gyro + accel all on
        MPU_Set_Rate(100);                         // 100Hz
    } else return 1;
    return 0;
}

uint8_t MPU_Set_Gyro_Fsr(uint8_t fsr)
{
    return MPU_Write_Byte(MPU_GYRO_CFG_REG, fsr << 3);
}

uint8_t MPU_Set_Accel_Fsr(uint8_t fsr)
{
    return MPU_Write_Byte(MPU_ACCEL_CFG_REG, fsr << 3);
}

uint8_t MPU_Set_LPF(uint16_t lpf)
{
    uint8_t data = 0;
    if (lpf >= 188) data = 1;
    else if (lpf >= 98) data = 2;
    else if (lpf >= 42) data = 3;
    else if (lpf >= 20) data = 4;
    else if (lpf >= 10) data = 5;
    else data = 6;
    return MPU_Write_Byte(MPU_CFG_REG, data);
}

uint8_t MPU_Set_Rate(uint16_t rate)
{
    uint8_t data;
    if (rate > 1000) rate = 1000;
    if (rate < 4) rate = 4;
    data = 1000 / rate - 1;
    MPU_Write_Byte(MPU_SAMPLE_RATE_REG, data);
    return MPU_Set_LPF(rate / 2);
}

short MPU_Get_Temperature(void)
{
    uint8_t buf[2];
    short raw;
    float temp;
    MPU_Read_Len(MPU_ADDR, MPU_TEMP_OUTH_REG, 2, buf);
    raw = ((uint16_t)buf[0] << 8) | buf[1];
    temp = 36.53 + ((double)raw) / 340;
    return temp * 100;
}

uint8_t MPU_Get_Gyroscope(short *gx, short *gy, short *gz)
{
    uint8_t buf[6], res;
    res = MPU_Read_Len(MPU_ADDR, MPU_GYRO_XOUTH_REG, 6, buf);
    if (res == 0) {
        *gx = ((uint16_t)buf[0] << 8) | buf[1];
        *gy = ((uint16_t)buf[2] << 8) | buf[3];
        *gz = ((uint16_t)buf[4] << 8) | buf[5];
    }
    return res;
}

uint8_t MPU_Get_Accelerometer(short *ax, short *ay, short *az)
{
    uint8_t buf[6], res;
    res = MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG, 6, buf);
    if (res == 0) {
        *ax = ((uint16_t)buf[0] << 8) | buf[1];
        *ay = ((uint16_t)buf[2] << 8) | buf[3];
        *az = ((uint16_t)buf[4] << 8) | buf[5];
    }
    return res;
}
