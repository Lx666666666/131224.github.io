#include "smg.h"
#include "system.h"
#include "gpio.h"

//共阴极数码管显示0~F的段码数据
uint8_t gsmg_code[17]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,
				0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};
//数码管端口8位数据同时操作，不影响高位
//写入数据到8位端口，数据低位对应端口低引脚
//GPIO_Pin：8位端口低位引脚
//data：写入数据
void SMG_Write_Data(u8 data)
{
#if 1
		uint16_t Set_Pins = 0, Rst_Pins = 0;
	//DataDir('O');
	if(data & 0x01) Set_Pins |= LED0_Pin;
	else Rst_Pins |= LED0_Pin;
	if(data & 0x02) Set_Pins |= LED1_Pin;
	else Rst_Pins |=  LED1_Pin;
	if(data & 0x04) Set_Pins |=  LED2_Pin;
	else Rst_Pins |=  LED2_Pin;
	if(data & 0x08) Set_Pins |=  LED3_Pin;
	else Rst_Pins |=  LED3_Pin;
	if(data & 0x10) Set_Pins |=  LED4_Pin;
	else Rst_Pins |=  LED4_Pin;
	if(data & 0x20) Set_Pins |=  LED5_Pin;
	else Rst_Pins |=  LED5_Pin;
	if(data & 0x40) Set_Pins |=  LED6_Pin;
	else Rst_Pins |=  LED6_Pin;
	if(data & 0x80) Set_Pins |=  LED7_Pin;
	else Rst_Pins |=  LED7_Pin;
	
	HAL_GPIO_WritePin(GPIOA, Set_Pins, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, Rst_Pins, GPIO_PIN_RESET);
#else
	 GPIOA->ODR = gsmg_code[data];  
#endif
}

//数码管显示
void SMG_Display(uint8_t dat[],uint8_t pos)
{
	u8 i=0;
	u8 pos_temp=pos-1;//从0开始

	for(i=pos_temp;i<8;i++)
	{
	   	switch(i)//位选
		{
			case 0: LSC=1;LSB=1;LSA=1;break;
			case 1: LSC=1;LSB=1;LSA=0;break;
			case 2: LSC=1;LSB=0;LSA=1;break;
			case 3: LSC=1;LSB=0;LSA=0;break;
			case 4: LSC=0;LSB=1;LSA=1;break;
			case 5: LSC=0;LSB=1;LSA=0;break;
			case 6: LSC=0;LSB=0;LSA=1;break;
			case 7: LSC=0;LSB=0;LSA=0;break;
		}
		SMG_Write_Data(dat[i]);
		//传送段选数据
		HAL_Delay(2);//延时一段时间，等待显示稳定
		SMG_Write_Data(0x00);//消隐
	}
}
