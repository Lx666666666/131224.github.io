#include "system.h"
#include "lcd1602.h"
//D0-D7设定方向：I-输入；O-输出
void DataDir(char dir)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	HAL_GPIO_WritePin(GPIOA, LED0_Pin|LED1_Pin|LED2_Pin|LED3_Pin|LED4_Pin|LED5_Pin|LED6_Pin|LED7_Pin, GPIO_PIN_SET);
	GPIO_InitStruct.Pin = LED0_Pin|LED1_Pin|LED2_Pin|LED3_Pin|LED4_Pin|LED5_Pin|LED6_Pin|LED7_Pin;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	if(dir == 'I')
	{
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	}
	else if(dir == 'O')
	{
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	}
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

//D0-D7读数据
uint8_t ReadData(void)
{
	uint8_t dat=0;
	//DataDir('I');
	if(HAL_GPIO_ReadPin(GPIOA, LED0_Pin)==GPIO_PIN_SET) dat|=0x01;
	if(HAL_GPIO_ReadPin(GPIOA, LED1_Pin)==GPIO_PIN_SET) dat|=0x02;
	if(HAL_GPIO_ReadPin(GPIOA, LED2_Pin)==GPIO_PIN_SET) dat|=0x04;
	if(HAL_GPIO_ReadPin(GPIOA, LED3_Pin)==GPIO_PIN_SET) dat|=0x08;
	if(HAL_GPIO_ReadPin(GPIOA, LED4_Pin)==GPIO_PIN_SET) dat|=0x10;
	if(HAL_GPIO_ReadPin(GPIOA, LED5_Pin)==GPIO_PIN_SET) dat|=0x20;
	if(HAL_GPIO_ReadPin(GPIOA, LED6_Pin)==GPIO_PIN_SET) dat|=0x40;
	if(HAL_GPIO_ReadPin(GPIOA, LED7_Pin)==GPIO_PIN_SET) dat|=0x80;
	return dat;
}

//D0-D7写数据
void WriteData(uint8_t dat)
{
	uint16_t Set_Pins = 0, Rst_Pins = 0;
	//DataDir('O');
	if(dat & 0x01) Set_Pins |= LED0_Pin;
	else Rst_Pins |= LED0_Pin;
	if(dat & 0x02) Set_Pins |= LED1_Pin;
	else Rst_Pins |= LED1_Pin;
	if(dat & 0x04) Set_Pins |= LED2_Pin;
	else Rst_Pins |= LED2_Pin;
	if(dat & 0x08) Set_Pins |= LED3_Pin;
	else Rst_Pins |= LED3_Pin;
	if(dat & 0x10) Set_Pins |= LED4_Pin;
	else Rst_Pins |= LED4_Pin;
	if(dat & 0x20) Set_Pins |= LED5_Pin;
	else Rst_Pins |= LED5_Pin;
	if(dat & 0x40) Set_Pins |= LED6_Pin;
	else Rst_Pins |= LED6_Pin;
	if(dat & 0x80) Set_Pins |= LED7_Pin;
	else Rst_Pins |= LED7_Pin;
	
	HAL_GPIO_WritePin(GPIOA, Set_Pins, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, Rst_Pins, GPIO_PIN_RESET);
}

//LCD忙等待
void LCD_Busy_Wait(void)
{
	uint8_t status;
	DataDir('I');
	RS_InstructionR();
	RW_Read();
	do
	{
		E_Set();
		__NOP();
		status = ReadData();
		E_Rst();
	}
	while(status & 0x80);
}

//写LCD指令
void LCD_Write_Cmd(uint8_t cmd)
{
	DataDir('O');
	WriteData(cmd);
	RS_InstructionR();
	RW_Write();
	E_Rst();
	RS_InstructionR();
	RW_Write();
	E_Set();
	__NOP();
	E_Rst();
	LCD_Busy_Wait();
}

//写LCD数据寄存器
void LCD_Write_Data(uint8_t dat)
{
	DataDir('O');
	WriteData(dat);
	RS_DataR();
	RW_Write();
	E_Set();
	__NOP();
	E_Rst();
	LCD_Busy_Wait();
}

//LCD初始化
void LCD_Init(void)
{
	LCD_Write_Cmd(0x38);
	HAL_Delay(2);
	LCD_Write_Cmd(0x01);
	HAL_Delay(2);
	LCD_Write_Cmd(0x06);
	HAL_Delay(2);
	LCD_Write_Cmd(0x0c);
	HAL_Delay(2);
}


//在x行（0-1），y列（0-15）显示字符串
void LCD_ShowString(uint8_t x, uint8_t y, char *str)
{
//	LCD_Write_Cmd(0x01);  //清屏 会有抖动现象
	uint8_t i=0;
	//设置显示起始位置
	if(x == 0)
		LCD_Write_Cmd(0x80|y);
	else if(x == 1)
		LCD_Write_Cmd(0xc0|y);
	//输出字符串
	for(i=0; i<16 && str[i]!='\0'; i++)
	{
		LCD_Write_Data(str[i]);
		HAL_Delay(2);
	}
}

void LCD_ShowChar(uint8_t x, uint8_t y,uint8_t dat)
{

	//设置显示起始位置
	if(x == 0)
		LCD_Write_Cmd(0x80|y);
	else if(x == 1)
		LCD_Write_Cmd(0xc0|y);
   LCD_Write_Data(dat);
}

//在x行（0-1），y列（0-15）显示数字
void LCD_ShowNum(uint8_t x, uint8_t y,uint8_t num)
{     

	//设置显示起始位置
	if(x == 0)
		LCD_Write_Cmd(0x80|y);
	else if(x == 1)
		LCD_Write_Cmd(0xc0|y);
	
   LCD_ShowChar(x,y,num+'0');
	
} 
