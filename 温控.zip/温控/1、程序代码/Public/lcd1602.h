#ifndef INC_LCD1602_H_
#define INC_LCD1602_H_

#include "system.h"
#include "gpio.h"
#include "stdint.h"
//位带定义
#define LCD_RS 	PBout(3)
#define LCD_RW 	PBout(4)
#define LCD_EN 	PBout(5)

//选择数据寄存器
#define RS_DataR() LCD_RS=1
#define RS_InstructionR() LCD_RS=0

//选择指令寄存器
//读操作
#define RW_Read() LCD_RW=1
//写操作
#define RW_Write() LCD_RW=0

//Enable操作：高电平-读取信息；下降沿-执行指令
#define E_Set() LCD_EN=1
#define E_Rst()  LCD_EN=0

////选择数据寄存器
//#define RS_DataR() HAL_GPIO_WritePin(GPIOB, RS_Pin, GPIO_PIN_SET)
//#define RS_InstructionR() HAL_GPIO_WritePin(GPIOB, RS_Pin, GPIO_PIN_RESET)

////选择指令寄存器
////读操作
//#define RW_Read() HAL_GPIO_WritePin(GPIOB, RW_Pin, GPIO_PIN_SET)
////写操作
//#define RW_Write() HAL_GPIO_WritePin(GPIOB, RW_Pin, GPIO_PIN_RESET)

////Enable操作：高电平-读取信息；下降沿-执行指令
//#define E_Set() HAL_GPIO_WritePin(GPIOB, E_Pin, GPIO_PIN_SET)
//#define E_Rst() HAL_GPIO_WritePin(GPIOB, E_Pin, GPIO_PIN_RESET)

void DataDir(char dir);
uint8_t ReadData(void);
void WriteData(uint8_t dat);
void LCD_Busy_Wait(void);
void LCD_Write_Cmd(uint8_t cmd);
void LCD_Write_Data(uint8_t dat);
void LCD_Init(void);	
void LCD_ShowString(uint8_t x, uint8_t y, char *str);
void LCD_ShowChar(uint8_t x, uint8_t y,uint8_t dat);
void LCD_ShowNum(uint8_t x, uint8_t y,uint8_t num);

#endif
