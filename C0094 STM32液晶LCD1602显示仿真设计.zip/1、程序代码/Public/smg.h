#ifndef _smg_H
#define _smg_H

#include "system.h"



//位带定义
#define LSA 	PBout(5)
#define LSB 	PBout(4)
#define LSC 	PBout(3)

#define HCA0	PAout(0)
#define HCA1	PAout(1)
#define HCA2	PAout(2)
#define HCA3	PAout(3)
#define HCA4	PAout(4)
#define HCA5	PAout(5)
#define HCA6	PAout(6)
#define HCA7	PAout(7)

extern uint8_t gsmg_code[17];

//函数声明
void SMG_Display(uint8_t dat[],uint8_t pos);
void SMG_Write_Data(u8 data);
#endif
